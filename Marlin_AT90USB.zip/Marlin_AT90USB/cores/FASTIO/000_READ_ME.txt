This core is a copy of the Arduino 1.6.12 core with the following changes:
 a) PID & VID are hard coded
 b) TX & RX LEDs are now conditional compiles
 c) PLUGGABLEUSB is disabled